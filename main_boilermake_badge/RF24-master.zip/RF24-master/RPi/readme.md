See RPi/RF24/readme.md
